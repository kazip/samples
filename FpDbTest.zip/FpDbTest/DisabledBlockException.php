<?php

namespace FpDbTest;

class DisabledBlockException extends \Exception
{

}