<?php

namespace FpDbTest;

use Exception;
use mysqli;

class Database implements DatabaseInterface
{
    public mysqli $mysqli;

    public function __construct(mysqli $mysqli)
    {
        $this->mysqli = $mysqli;
    }

    const TYPE_COMMENT = 1;
    const TYPE_PLACEHOLDER = 2;
    const TYPE_TEXT = 3;

    private function checkToken(string $str): array
    {
        if (preg_match('/^([?][#ads]?)/ius', $str, $m)) {
            return [self::TYPE_PLACEHOLDER, $m[1]];
        }

        if (preg_match('#^(/\*([^*]+|[*]+[^/*])*[*]/|--[^\r\n]*)#ius', $str, $m)) {
            return [self::TYPE_COMMENT, $m[1]];
        }

        if (preg_match('#^(".*?")#ius', $str, $m)) {
            return [self::TYPE_TEXT, $m[1]];
        }

        if (preg_match("#^('.*?')#ius", $str, $m)) {
            return [self::TYPE_TEXT, $m[1]];
        }

        if (preg_match("#^('((\\.)|.['\\\])*')#ius", $str)) {
            return [self::TYPE_TEXT, $m[1]];
        }

        if (preg_match("#^(.)#ius", $str, $m)) {
            return [self::TYPE_TEXT, $m[1]];
        }

        return [];
    }

    private function findPlaceholdersPositions(string $query): array
    {
        $positions = [];
        $i = 0;

        while ($i < strlen($query)) {
            $r = $this->checkToken(substr($query, $i));

            if ($r[0] == self::TYPE_PLACEHOLDER) {
                $positions[] = [
                    'pos'=> $i,
                    'type' => $r[1],
                    'len' => strlen($r[1])
                ];
            }
            $i += strlen($r[1]);
        }

        return $positions;
    }

    private function replaceArray($args): string
    {
        $escaped = array_map([$this, 'replaceVal'], $args);
        if (array_is_list($args)) {
            return implode(", ", $escaped);
        } else {
            $result = [];
            foreach ($escaped as $key=>$val) {
                $result[] = "`$key` = $val";
            }
            return implode(", ", $result);
        }
    }

    /**
     * @throws DisabledBlockException
     * @throws Exception
     */
    private function replaceInt($val): string
    {
        if (is_int($val) || is_string($val) || is_bool($val)) {
            return (string)(int)$val;
        } elseif ($val instanceof Skip) {
            throw new DisabledBlockException();
        } else {
            throw new Exception('Bad intval type');
        }

    }

    /**
     * @throws Exception
     */
    private function escapeIdent(string $ident): string
    {
        if (str_contains($ident, "`")) {
            throw new Exception('Bad identificator');
        }
        return "`$ident`";
    }

    /**
     * @throws DisabledBlockException
     * @throws Exception
     */
    private function replaceIdent($args): string
    {
        if (is_array($args)) {
            $mapped = array_map([$this, 'escapeIdent'], $args);
            return implode(", ", $mapped);
        } elseif (is_string($args)) {
            return $this->escapeIdent($args);
        } elseif ($args instanceof Skip) {
            throw new DisabledBlockException();
        } else {
            throw new Exception("Bad ident type");
        }

    }

    private function inBlock(array $blocks, int $position): array {
        foreach ($blocks as $block) {
            if ($position > $block['begin'] && $position < $block['end']) {
                return $block;
            }
        }

        return [];
    }

    /**
     * @throws DisabledBlockException
     * @throws Exception
     */
    private function replaceVal($val): string
    {
        if (is_string($val)) {
            return "'".mysqli_escape_string($this->mysqli, $val)."'";
        } elseif (is_int($val)) {
            return $this->replaceInt($val);
        } elseif (is_null($val)) {
            return "NULL";
        } elseif (is_bool($val)) {
            return (string)(int)$val;
        } elseif ($val instanceof Skip) {
            throw new DisabledBlockException();
        } else {
            throw new Exception("Bad value type");
        }
    }


    /**
     * @throws Exception
     */
    private function findBlocks(string $query): array
    {
        $beginBlock = false;
        $blocks = [];
        for ($i=0;$i<strlen($query);$i++) {
            if ($query[$i] == "{") {
                if ($beginBlock === false) {
                    $beginBlock = $i;
                } else {
                    throw new Exception('Folded blocks are not supported');
                }
            }

            if ($query[$i] == "}") {
                if ($beginBlock === false) {
                    throw new Exception('Block close before opening');
                }
                $blocks[] = ['begin' => $beginBlock, 'end' => $i];
                $beginBlock = false;
            }
        }

        return $blocks;
    }

    /**
     * @throws Exception
     */
    public function buildQuery(string $query, array $args = []): string
    {
        $blocks = $this->findBlocks($query);
        $replaces = [];
        $positions = $this->findPlaceholdersPositions($query);

        foreach ($positions as $k=>$position) {

            $inBlock = $this->inBlock($blocks, $position['pos']);

            if (!isset($args[$k])) {
                throw new Exception('Bad number of arguments');
            }

            try {

                $replaces[$position['pos']] = match ($position['type']) {
                    '?a' => [
                        'len' => 2,
                        'replace' => $this->replaceArray($args[$k]),
                    ],
                    '?d' => [
                        'len' => 2,
                        'replace' => $this->replaceInt($args[$k]),
                    ],
                    '?#' => [
                        'len' => 2,
                        'replace' => $this->replaceIdent($args[$k]),
                    ],
                    '?' => [
                        'len' => 1,
                        'replace' => $this->replaceVal($args[$k]),
                    ],
                    default => throw new Exception('Bad placeholder syntax')
                };

                if ($inBlock) {
                    $replaces[$inBlock['begin']] = [
                        'len' => 1,
                        'replace' => "",
                    ];

                    $replaces[$inBlock['end']] = [
                        'len' => 1,
                        'replace' => "",
                    ];
                }

            } catch (DisabledBlockException) {
                if ($inBlock) {
                    $replaces[$inBlock['begin']] = [
                        'len' => $inBlock['end']-$inBlock['begin']+1,
                        'replace' => "",
                    ];
                } else {
                    throw new Exception('Attempt to skip argument outside of block');
                }

            }
        }

        ksort($replaces);

        $offset = 0;
        foreach ($replaces as $pos=>$replace) {
            $query = substr_replace($query, $replace['replace'], $pos + $offset, $replace['len']);
            $offset += strlen($replace['replace']) - $replace['len'];
        }

        return $query;
    }

    public function skip(): Skip
    {
        return new Skip();
    }
}
