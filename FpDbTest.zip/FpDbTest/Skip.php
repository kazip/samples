<?php

namespace FpDbTest;
class Skip
{

}